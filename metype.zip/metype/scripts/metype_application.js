var metype = document.createElement('script');
metype.type = 'text/javascript';
metype.async = true;
metype.src = 'https://staging.metype.com/quintype-metype/assets/application.js';
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(metype);